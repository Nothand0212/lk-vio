#pragma once

#include <pangolin/gl/glfont.h>

namespace pangolin {
GlFont& default_font();
}
